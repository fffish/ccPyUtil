from .main import get_local_ip, print_color

__all__ = ['get_local_ip', 'print_color']
