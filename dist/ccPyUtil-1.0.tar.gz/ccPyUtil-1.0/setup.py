from setuptools import setup

setup(
    name='ccPyUtil',
    version='1.0',
    description='some useful tools',
    author='lcc',
    author_email='linchao9528@gmail.com',
    packages=['ccPyUtil'],
)
